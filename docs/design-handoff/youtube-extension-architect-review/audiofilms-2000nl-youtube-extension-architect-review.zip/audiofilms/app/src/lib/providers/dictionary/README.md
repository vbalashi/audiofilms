# Dictionary Provider System

This directory contains the dictionary provider implementation for fetching word definitions.

## Overview

The dictionary provider system uses a provider-based architecture similar to the subtitle provider system. This allows easy switching between different dictionary services without changing application code.

## Available Providers

### 2000NL Platform Dictionary Provider

Uses the 2000NL Platform API as the dictionary authority for Dutch lookup and user progress context.

This is the preferred provider for AudioFilms Dutch shadowing because it returns curated dictionary entries and can include 2000NL user state. Plain lookup is read-only; learning mutations belong to the 2000NL `/api/platform/v1/actions` endpoint and should be wired only through explicit user actions.

**Configuration:**
```bash
DICTIONARY_PROVIDER=2000nl
DICTIONARY_2000NL_API_BASE=https://2000.dilum.io/api/platform/v1
DICTIONARY_2000NL_ACCESS_TOKEN=your_supabase_user_access_token_here
```

`DICTIONARY_2000NL_ACCESS_TOKEN` is a local read/dogfood fallback. Authenticated
write routes must receive a forwarded user Bearer token and must not use this
environment token as write identity.

Current `/api/dict` lookup does not request 2000NL user state. State-aware
dictionary cards require the V2 contract described in the extension
backend/UI contract notes.

### OpenAI Dictionary Provider

Uses the OpenAI chat completions API for context-aware dictionary-style definitions.

This is useful when you already operate an OpenAI or Azure OpenAI setup elsewhere and want to reuse it here.

**Features:**
- Multi-language support
- Context-aware definitions
- Standard OpenAI and Azure OpenAI support
- GPT-5 reasoning disabled for faster dictionary lookups

**Configuration:**
```bash
DICTIONARY_PROVIDER=openai
OPENAI_API_KEY=your_api_key_here
OPENAI_MODEL=gpt-5.2
```

### OpenRouter Dictionary Provider

Uses Large Language Models (LLMs) via OpenRouter API to provide intelligent, context-aware word definitions.

This is the current runtime default dictionary provider.

**Features:**
- Multi-language support
- Context-aware definitions
- Configurable prompts
- Support for idioms and collocations
- Monolingual dictionary style (ideal for language learners)

**Configuration:**
```bash
DICTIONARY_PROVIDER=openrouter
OPENROUTER_API_KEY=your_api_key_here
OPENROUTER_DICTIONARY_MODEL=x-ai/grok-4.1-fast:free
```

**Supported Models:**
- `x-ai/grok-4.1-fast:free` (current runtime default)
- `google/gemini-flash-1.5`
- `openai/gpt-3.5-turbo` (paid, good balance of speed and cost)
- `anthropic/claude-3-5-sonnet` (paid, excellent quality)
- `openai/gpt-4` (paid, high quality)
- Any other OpenRouter-supported model (see https://openrouter.ai/models)
- **IMPORTANT**: Model availability changes frequently - always verify on OpenRouter

### Free Dictionary Provider

Uses the free Dictionary API (dictionaryapi.dev) as a fallback.

This is the explicit fallback provider, not the default.

**Features:**
- Completely free
- No API key required
- Provides definitions with examples

**Limitations:**
- English only
- No context awareness
- Limited vocabulary coverage

**Configuration:**
```bash
DICTIONARY_PROVIDER=free-dictionary
```

## Usage

### In API Routes

```typescript
import { getConfiguredDictionaryProvider } from '@/lib/providers/dictionary';

const provider = getConfiguredDictionaryProvider();
const result = await provider.getDefinition(
  'word',      // The word to define
  'en',        // Source language
  'context'    // Optional: sentence containing the word
);

console.log(result.definition);
```

### Direct Provider Usage

```typescript
import { OpenRouterDictionaryProvider } from '@/lib/providers/dictionary';

const provider = new OpenRouterDictionaryProvider(
  'your-api-key',
  'google/gemini-flash-1.5',  // optional model
  'custom prompt template'  // optional custom prompt
);

const result = await provider.getDefinition('hello', 'en');
```

## Custom Prompt Template

You can customize how the LLM generates definitions by setting the `OPENROUTER_DICTIONARY_PROMPT` environment variable.

**Available placeholders:**
- `{{word}}` - The word being defined
- `{{sourceLanguage}}` - The language of the word
- `{{context}}` - The context sentence (if provided)

**Default prompt:**
```
Define the word "{{word}}" in "{{sourceLanguage}}" using a style similar to a monolingual dictionary for language learners. Context: "{{context}}".

Your answer should be brief, clear, and contain only the definition of target word "{{word}}".

Avoid cognates or translations unless strictly necessary. If the word functions as a part of a phrase, idiom, or collocation, describe its meaning in that phrase as well, indicating both standalone and contextual meanings separately.
```

## API Endpoint

**GET** `/api/dict`

**Query Parameters:**
- `word` (required) - The word to define
- `language` (optional) - The source language (default: 'en')
- `context` (optional) - Context sentence containing the word

**Example:**
```bash
curl "http://localhost:3000/api/dict?word=hello&language=en&context=Hello%20world"
```

**Response:**
```json
{
  "query": "huis",
  "result": {
    "word": "huis",
    "language": "nl",
    "definition": "het-woord\n\nA place where people live...",
    "context": "Het huis is groot."
  },
  "definitions": ["het-woord", "A place where people live..."],
  "cards": [
    {
      "id": "entry-id",
      "entryId": "entry-id",
      "cardTypeId": "word-to-definition",
      "headword": "huis",
      "language": "nl",
      "partOfSpeech": "zn",
      "gender": "het",
      "dictionary": {
        "id": "dictionary-id",
        "slug": "nl-vandale",
        "name": "VanDale Dutch"
      },
      "meanings": [
        {
          "definition": "A place where people live...",
          "examples": [],
          "idioms": []
        }
      ],
      "availableActions": ["start-learning", "review-card"]
    }
  ],
  "meta": {
    "provider": "2000nl",
    "fallbackUsed": false,
    "responseVersion": "overlay-v1"
  }
}
```

For 2000NL, `cards[]` is a shallow AudioFilms overlay projection where one
card maps to one top-level 2000NL `lookup.items[]` result. The response does not
expose `entry.raw`; consumers should render `cards[]`.

Explicit per-card mutations go through the AudioFilms backend:

- `POST /api/dict/actions` proxies supported card actions to 2000NL
  `/api/platform/v1/actions` with `cardTypeId: "word-to-definition"`.
- `POST /api/dict/translation` proxies provider-backed translation requests to
  2000NL `/api/platform/v1/translation`.

**Error Response:**
```json
{
  "error": "Word not found",
  "translateUrl": "https://translate.google.com/..."
}
```

## Error Handling

The system uses a custom `DictionaryError` class with the following error codes:

- `NOT_FOUND` - Word not found in dictionary (404)
- `RATE_LIMIT` - API rate limit exceeded (429)
- `INVALID_INPUT` - Missing or invalid parameters (400)
- `API_ERROR` - General API error (500)

## Adding a New Provider

1. Create a new provider class that implements the `DictionaryProvider` interface:

```typescript
import type { DictionaryProvider, DictionaryResult } from '@/types/dictionary';

export class MyCustomProvider implements DictionaryProvider {
  async getDefinition(
    word: string,
    sourceLanguage: string,
    context?: string
  ): Promise<DictionaryResult> {
    // Your implementation
  }
}
```

2. Add the provider to the factory in `index.ts`:

```typescript
case 'my-custom':
  return new MyCustomProvider(/* config */);
```

3. Update the environment configuration to support the new provider.

## Testing

To test the dictionary provider:

1. Set up your `.env.local` with the appropriate configuration
2. Make a request to `/api/dict?word=test&language=en`
3. Check the response for the definition

## Cost Considerations

### OpenRouter Provider
- Some models may be free or have usage limits (check OpenRouter's current offerings)
- Paid models charge per token (typically $0.001-0.01 per request)
- Consider implementing caching for frequently looked-up words
- Always check https://openrouter.ai/models for current pricing

### Free Dictionary Provider
- Completely free
- No rate limits (reasonable use)
- Good fallback option

## Best Practices

1. **Use context when available** - Provides more accurate definitions
2. **Cache results** - Implement caching to reduce API calls and costs
3. **Fallback strategy** - Prefer `2000nl` for Dutch curated lookup, use `openai` or `openrouter` for generated/contextual fallback, then fall back to Free Dictionary for English words
4. **Rate limiting** - Implement user-side rate limiting to prevent abuse
5. **Error handling** - Always handle errors gracefully with user-friendly messages
